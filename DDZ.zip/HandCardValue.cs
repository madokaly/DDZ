namespace Proj_ddz_vr
{
    /// <summary>
    /// 手牌价值类
    /// </summary>
    public struct HandCardValue
    {
        /// <summary>
        /// 手牌总价值(10为0)
        /// </summary>
        public int sumValue;

        /// <summary>
        /// 打完所需轮数
        /// </summary>
        public int needRound;
    }
}
