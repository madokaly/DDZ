using Cysharp.Threading.Tasks;
using DBTXR;
using GameFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Proj_ddz_vr
{
    /// <summary>
    /// 手牌数据类--AI
    /// </summary>
    public class HandCardData
    {
        /// <summary>
        /// 手牌序列(有花色值域0~52,56)
        /// </summary>
        public List<int> handColorCardList = new List<int>();
        /// <summary>
        /// 手牌序列(无花色值域3~17)
        /// </summary>
        public List<int> handCardList = new List<int>();
        /// <summary>
        /// 值域对应的牌数
        /// </summary>
        public int[] handCardValueList = new int[18];
        /// <summary>
        /// 手牌总数
        /// </summary>
        public int handCardsCount;
        /// <summary>
        /// 玩家角色
        /// </summary>
        public GameRole gameRole = GameRole.None;
        /// <summary>
        /// 玩家座位
        /// </summary>
        public int ownIndex = -1;
        /// <summary>
        /// 要打出去的牌型
        /// </summary>
        public CardGroupData newCardGroupData = new CardGroupData();
        /// <summary>
        /// 要打出去的牌-无花色
        /// </summary>
        public List<int> putCardList = new List<int>();
        /// <summary>
        /// 要打出的牌-带花色
        /// </summary>
        public List<int> putCardColorList = new List<int>();
        /// <summary>
        /// 手牌价值
        /// </summary>
        public HandCardValue? handCardValue;
        /// <summary>
        /// 自己回合
        /// </summary>
        public bool selfTurn;
        /// <summary>
        /// 本轮是否叫了地主
        /// </summary>
        public bool isCallLandlord = true;

        /// <summary>
        /// 加倍倍率
        /// </summary>
        public int addSorce = 1;

        /// <summary>
        /// DouZeroAi类
        /// </summary>
        public DouZeroAIServer DouZeroAIServer;

        public bool IsLandlord => ownIndex == GameSituationControl.I.landlordId;

        /// <summary>
        /// 手牌交互管理类
        /// </summary>
        public HandCardInteractorManager handCardInteractorMgr;

        public HandCardInteractorManager HandCardInteractorMgr
        {
            get
            {
                if (handCardInteractorMgr == null)
                    handCardInteractorMgr = UnityEngine.Object.FindObjectOfType<HandCardInteractorManager>();
                return handCardInteractorMgr;
            }
        }

        /// <summary>
        /// 退出时清理数据
        /// </summary>
        public virtual void ClearWhenOver()
        {
            gameRole = GameRole.None;
            handColorCardList.Clear();
            handCardList.Clear();
            Array.Clear(handCardValueList, 0, handCardValueList.Length);
            handCardValue = null;
            ClearPutCardList();
            addSorce = 1;
            selfTurn = false;
        }

        /// <summary>
        /// 清空出牌列表
        /// </summary>
        public void ClearPutCardList()
        {
            putCardList.Clear();
            putCardColorList.Clear();
        }

        /// <summary>
        /// 有花色手牌转换成无花色
        /// </summary>
        public void GetHandCardList()
        {
            handCardList.Clear();
            Array.Clear(handCardValueList, 0, handCardValueList.Length);

            for (int i = 0; i < handColorCardList.Count; i++)
            {
                //转换成无花色
                handCardList.Add(handColorCardList[i] / 4 + 3);
                //值域对应牌数
                handCardValueList[(handColorCardList[i] / 4 + 3)]++;
            }
        }

        /// <summary>
        /// 获得队友剩余牌数
        /// </summary>
        public int GetFriendCardsCount()
        {
            if (ownIndex != GameSituationControl.I.landlordId)
            {
                return gameRole == GameRole.PeasantTop ? GameSituationControl.I.unitHandCardList[(int) GameRole.PeasantDown] : GameSituationControl.I.unitHandCardList[(int) GameRole.PeasantTop];
            }
            return int.MaxValue;
        }

        /// <summary>
        /// 获得敌人剩余牌数
        /// </summary>
        public int GetEnemyCardsCount()
        {
            if (ownIndex != GameSituationControl.I.landlordId)
            {
                return GameSituationControl.I.unitHandCardList[0];
            }
            int temp = int.MaxValue;
            temp = Mathf.Min(GameSituationControl.I.unitHandCardList[1], GameSituationControl.I.unitHandCardList[2]);
            return temp;
        }

        /// <summary>
        /// 方便手牌的展示
        /// </summary>
        public void SortHandColorCardList()
        {
            //排序
            UtilityHelper.SortDownList(handColorCardList);
        }

        public virtual void Init()
        {
            GetHandCardList();
            //排序
            UtilityHelper.SortDownList(handColorCardList);
            UtilityHelper.SortDownList(handCardList);
            //当前手牌数
            handCardsCount = handCardList.Count;
            //剩余手牌数
            GameSituationControl.I.unitHandCardList[(int) gameRole] = handCardsCount;
            //总手牌价值
            if (IsLandlord)
                handCardValue = CardAlgorithm.GetHandCardValue(this);
            HandCardInteractorMgr.handCardInteractors[ownIndex].Init(gameRole == GameRole.Landlord);
            //douzero
            DouZeroAIServer = new DouZeroAIServer(gameRole, GameSituationControl.I.diPai.ToList<int>());
        }

        public async UniTask BeforeLand()
        {
            await UniTask.DelayFrame(1);
            GetHandCardList();
            //当前手牌数
            handCardsCount = handCardList.Count;
            //总手牌价值
            handCardValue = CardAlgorithm.GetHandCardValue(this);
            XRLog.LogWarning($"总价值{handCardValue.Value.sumValue}");
        }

        /// <summary>
        /// 出牌后处理
        /// </summary>
        public virtual void AfterPutCards()
        {
            //变更手牌总价值
            //handCardValue = CardAlgorithm.GetHandCardValue(this);
            //变更手牌数量
            handCardsCount = handCardList.Count;
            GameSituationControl.I.SetNewCardGroupData(this.newCardGroupData);
            //变更控手对象
            GameSituationControl.I.SetCardDroit(ownIndex);
            //变更数据
            GameSituationControl.I.SetInfoOnOutCardList(ownIndex, putCardList, handCardsCount, putCardColorList, gameRole);

            //特效，音效
            if (newCardGroupData.cgType == CardGroupType.CT_BOMB_CARD ||
                newCardGroupData.cgType == CardGroupType.CT_KING_CARD)
            {
                MsgDispatcher.SendMessage(GlobalEventType.ShowBoomPrefab, ownIndex);
                if (newCardGroupData.cgType == CardGroupType.CT_KING_CARD)
                {
                    EffectManager.Instance.ShowKingEffect().Forget();
                    UtilityHelper.PlayRocket().Forget();
                }
            }
            else if (newCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_ONE_LINE ||
                      newCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_TWO_LINE)
            {
                EffectManager.Instance.ShowPlaneEffect(ownIndex).Forget();
                UtilityHelper.PlayVoice(GameAudioType.audio_plane_fly);
            }
        }

        /// <summary>
        /// 出牌函数
        /// </summary>
        /// <returns></returns>
        public bool PutCards(bool isAi = true)
        {
            for (int i = 0; i < putCardList.Count; i++)
            {
                //有花色
                int putColorCard = -1;
                if (PutOneCard(putCardList[i], out putColorCard, isAi))
                {
                    putCardColorList.Add(putColorCard);
                    if (!isAi)
                    {
                        handColorCardList.Add(putColorCard);
                    }
                }
                else
                {
                    //排序
                    UtilityHelper.SortDownList(handColorCardList);
                    return false;
                }
            }
            //排序
            UtilityHelper.SortDownList(handColorCardList);
            return true;
        }

        /// <summary>
        /// 出牌
        /// </summary>
        /// <param name="putCard"></param>
        /// <param name="putColorCard"></param>
        /// <returns></returns>
        public bool PutOneCard(int putCard, out int putColorCard, bool isAi)
        {
            bool ret = false;
            putColorCard = -1;
            if (isAi)
            {
                handCardValueList[putCard]--;
                if (handCardValueList[putCard] < 0) return false;
            }
            //处理无花色手牌
            for (int i = 0; i < handCardList.Count; i++)
            {
                if (handCardList[i] == putCard)
                {
                    //移除
                    if (isAi)
                        handCardList.Remove(putCard);
                    ret = true;
                    break;
                }
            }

            //处理有花色手牌
            int k = (putCard - 3) * 4; //转换
            for (int i = 0; i < handColorCardList.Count; i++)
            {
                for (int j = k; j < k + 4; j++)
                {
                    if (handColorCardList[i] == j)
                    {
                        putColorCard = j;
                        handColorCardList.Remove(j);
                        return ret;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 明牌
        /// </summary>
        public virtual async UniTask MingPai()
        {
            await UniTask.DelayFrame(1);
            handCardValue = CardAlgorithm.GetHandCardValue(this);
            if (handCardValue.Value.sumValue >= 20)
            {
                var mingPaiScore = Mathf.Max(5, GameSituationControl.I.mingPaiScore);
                GameSituationControl.I.AddLandScore(mingPaiScore, ScoreType.MingPai);
            }
            if (handCardValue.Value.sumValue >= 17)
            {
                var mingPaiScore = Mathf.Max(4, GameSituationControl.I.mingPaiScore);
                GameSituationControl.I.AddLandScore(mingPaiScore, ScoreType.MingPai);
            }
            if (handCardValue.Value.sumValue >= 15)
            {
                var mingPaiScore = Mathf.Max(3, GameSituationControl.I.mingPaiScore);
                GameSituationControl.I.AddLandScore(mingPaiScore, ScoreType.MingPai);
            }
        }

        /// <summary>
        /// 叫地主
        /// </summary>
        /// <returns></returns>
        public virtual async UniTask<bool> CallLandlord()
        {
            //显示白灯光
            EffectManager.Instance.ShowLightEffect(EffectType.LightWhiteEffect, ownIndex).Forget();
            //倒计时开始
            MsgDispatcher.SendMessage(GlobalEventType.BeginProgress, ownIndex, UtilityConst.DelayCallLand);
            handCardValue ??= CardAlgorithm.GetHandCardValue(this);
            //让AI等待几秒
            int i = UnityEngine.Random.Range(2, 4);
            await UtilityHelper.WaitSeconds(i);
            //关闭白灯光
            EffectManager.Instance.RecycleLightEffect(EffectType.LightWhiteEffect);
            if (handCardValue.Value.sumValue >= 0)
            {
                //叫地主显示黄灯光
                EffectManager.Instance.ShowLightEffect(EffectType.LightYellowEffect, ownIndex).Forget();
            }
            //倒计时结束
            MsgDispatcher.SendMessage(GlobalEventType.EndProgress, ownIndex);
            isCallLandlord = handCardValue.Value.sumValue >= 0;
            return isCallLandlord;
        }

        /// <summary>
        /// 抢地主
        /// </summary>
        /// <returns></returns>
        public virtual async UniTask<bool> RobLandlord()
        {
            if (!isCallLandlord) return false;
            //显示白灯光
            EffectManager.Instance.ShowLightEffect(EffectType.LightWhiteEffect, ownIndex).Forget();
            //倒计时开始
            MsgDispatcher.SendMessage(GlobalEventType.BeginProgress, ownIndex, UtilityConst.DelayCallLand);
            handCardValue ??= CardAlgorithm.GetHandCardValue(this);
            //让AI等待几秒
            int i = UnityEngine.Random.Range(2, 4);
            await UtilityHelper.WaitSeconds(i);
            //关闭白灯光
            EffectManager.Instance.RecycleLightEffect(EffectType.LightWhiteEffect);
            if (handCardValue.Value.sumValue >= 10)
            {
                //关闭其他灯光
                EffectManager.Instance.RecycleLightEffect(EffectType.LightYellowEffect);
                EffectManager.Instance.RecycleLightEffect(EffectType.LightYellowSilkEffect);
                //抢地主显示黄丝带灯光
                EffectManager.Instance.ShowLightEffect(EffectType.LightYellowSilkEffect, ownIndex).Forget();
                //播放音效
                UtilityHelper.PlayVoice(GameAudioType.audio_lord_get);
            }
            //倒计时结束
            MsgDispatcher.SendMessage(GlobalEventType.EndProgress, ownIndex);
            return handCardValue.Value.sumValue >= 10;
        }

        /// <summary>
        /// 加倍
        /// </summary>
        /// <returns></returns>
        public virtual async UniTask AddScore()
        {
            //倒计时开始
            MsgDispatcher.SendMessage(GlobalEventType.BeginProgress, ownIndex, UtilityConst.DelayCallLand);
            //让AI等待几秒
            handCardValue ??= CardAlgorithm.GetHandCardValue(this);
            int i = UnityEngine.Random.Range(2, 4);
            await UtilityHelper.WaitSeconds(i);
            if (handCardValue.Value.sumValue >= 20)
            {
                addSorce = 4;
            }
            else if (handCardValue.Value.sumValue >= 17)
            {
                addSorce = 2;
            }
            //倒计时结束
            MsgDispatcher.SendMessage(GlobalEventType.EndProgress, ownIndex);
            //加倍
            GameSituationControl.I.AddLandScore(addSorce, IsLandlord ? ScoreType.Landlord : ScoreType.NongMin);
        }

        /// <summary>
        /// 判断输赢
        /// </summary>
        /// <returns></returns>
        public bool JudgeWin()
        {
            return handCardsCount == 0;
        }

        /// <summary>
        /// 获得可出牌并出牌
        /// </summary>
        public virtual async UniTask GetAndPutCards()
        {
            //倒计时开始
            MsgDispatcher.SendMessage(GlobalEventType.BeginProgress, ownIndex, UtilityConst.DelayForPutCards);
            selfTurn = true;
            /*//owner出牌
            AiPlayAlgorithm.GetPutCardList(this).Forget();*/
            //Douzero出牌
            await GetCardForDouZero();
            //让AI等待几秒再出牌
            int i = UnityEngine.Random.Range(5, 8);
            //await UtilityHelper.WaitSeconds(i);
            PutCards();
            //如果正确出牌则变更全局类数据
            if (newCardGroupData.cgType != CardGroupType.CT_ERROR && newCardGroupData.cgType != CardGroupType.CT_ZERO)
            {
                //出牌后处理
                AfterPutCards();
                //展示出牌
                ShowPutCards();
                //炸弹加倍
                AddLandScore();
            }
            else
            {
                //变更数据(为了douzero)
                GameSituationControl.I.SetInfoOnOutCardList(ownIndex, null, handCardsCount, new List<int>(), gameRole);
                XRLog.LogWarning($"玩家{ownIndex}不出");
            }
            //倒计时结束
            MsgDispatcher.SendMessage(GlobalEventType.EndProgress, ownIndex);
            //判断胜负
            bool win = JudgeWin();
            selfTurn = false;
            //发送对应消息
            if (win)
            {
                MsgDispatcher.SendMessage(GlobalEventType.OneGameOver, ownIndex);
            }
            else
            {
                XRLog.LogWarning("下一位玩家");
                MsgDispatcher.SendMessage(GlobalEventType.NextPlayerPutCards);
            }
        }

        private List<List<int>> tempCardPlayActionSeq = new List<List<int>>();
        /// <summary>
        /// 从DouZero请求出牌
        /// </summary>
        private async UniTask GetCardForDouZero()
        {
            Array.Clear(douCardValue, 0, douCardValue.Length);
            putCardList.Clear();
            putCardColorList.Clear();
            GameSituationControl.I.GetPredictInfos(ownIndex, out List<List<int>> cardPlayActionSeq,
                out List<int> playerHandCards, out List<int> otherHandCards,
                out int landlordLeftCardsNum, out int landlordDownLeftCardsNum, out int landloardUpLeftCardsNum,
                out List<int> lastLandlordMove, out List<int> lastLandlordDownMove, out List<int> lastLandlordUpMove,
                out int bombNum, out List<int> landlordPlayedCards, out List<int> landlordDownPlayedCards,
                out List<int> landlordUpPlayedCards);
            List<int> tempPlayerHandCards = null;
            List<int> tempOtherHandCards = null;

            if (cardPlayActionSeq != null)
            {
                for (int i = 0; i < cardPlayActionSeq.Count; i++)
                {
                    tempCardPlayActionSeq.Add(cardPlayActionSeq[i].ToList());
                }
            }
            if (playerHandCards != null)
            {
                tempPlayerHandCards = ListPool.Instance.GetPool();
                tempPlayerHandCards = playerHandCards.ToList();
            }
            if (otherHandCards != null)
            {
                tempOtherHandCards = ListPool.Instance.GetPool();
                tempOtherHandCards = otherHandCards.ToList();
            }
           
            var webResult = await DouZeroAIServer.Predict(tempCardPlayActionSeq, tempPlayerHandCards, tempOtherHandCards, landlordLeftCardsNum, landlordDownLeftCardsNum, 
                landloardUpLeftCardsNum, lastLandlordMove, lastLandlordDownMove, lastLandlordUpMove, bombNum, landlordPlayedCards, landlordDownPlayedCards, landlordUpPlayedCards);
            XRLog.LogWarning(webResult.message);
            AnalysisWebResult(webResult);
            ListPool.Instance.RefreshList(tempPlayerHandCards);
            ListPool.Instance.RefreshList(tempOtherHandCards);
            ListPool.Instance.RefreshList(lastLandlordMove);
            ListPool.Instance.RefreshList(lastLandlordDownMove);
            ListPool.Instance.RefreshList(lastLandlordUpMove);
            ListPool.Instance.RefreshList(landlordPlayedCards);
            ListPool.Instance.RefreshList(landlordDownPlayedCards);
            ListPool.Instance.RefreshList(landlordUpPlayedCards);
            tempCardPlayActionSeq.Clear();
        }

        private int[] douCardValue = new int[18];
        /// <summary>
        /// 解析douzero结果
        /// </summary>
        private void AnalysisWebResult(WebResult webResult)
        {
            int index = -1;
            float win = -1;
            if(webResult.status != 0) return;
            var result = webResult.win_rates;
            var values = result.Values.ToList();
            //找出最大的胜率
            for (int i = 0; i < values.Count; i++)
            {
                var temp = float.Parse(values[i]);
                if (temp > win)
                {
                    win = temp;
                    index = i;
                }
            }

            var cards = result.Keys.ElementAt(index);
            if (string.IsNullOrEmpty(cards))
            {
                newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ZERO, 0, 0);
            }
            else
            {
                var putCards = UtilityHelper.GetHandCardArray(cards);
                for (int i = 0; i < putCards.Length; i++)
                {
                    douCardValue[putCards[i]]++;
                    putCardList.Add(putCards[i]);
                }
                newCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(douCardValue);
            }
        }
        
        public void AddLandScore()
        {
            if (newCardGroupData.cgType == CardGroupType.CT_BOMB_CARD || newCardGroupData.cgType == CardGroupType.CT_KING_CARD)
            {
                GameSituationControl.I.AddLandScore(2, ScoreType.Boom);
            }
        }

        #region 私有方法
        /// <summary>
        /// 展示出牌
        /// </summary>
        private void ShowPutCards()
        {
            HandCardInteractorMgr.handCardInteractors[ownIndex].ShowPutCards(putCardColorList);
        }

        #endregion
    }
}
