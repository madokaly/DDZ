using Cysharp.Threading.Tasks;
using DBTXR;

namespace Proj_ddz_vr
{
    public static class AiPlayAlgorithm
    {
        /// <summary>
        /// 获得最佳出牌序列
        /// </summary>
        public static async UniTask GetPutCardList(HandCardData handCardData)
        {
            await UniTask.DelayFrame(1);
            if (GameSituationControl.I.cardDroit == handCardData.ownIndex || GameSituationControl.I.cardDroit == -1)
            {
                GetPutCardList_Active(handCardData);
            }
            else
            {
                GetPutCardList_Limit(handCardData);
            }
        }

        /// <summary>
        /// 获取最佳出牌序列--主动出牌
        /// </summary>
        /// <param name="handCardData"></param>
        public static void GetPutCardList_Active(HandCardData handCardData)
        {
            handCardData.ClearPutCardList();
            //剪枝：最后一手牌直接出
            CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
            if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
            {
                PutAllHandCards(handCardData, surCardGroupData);
                return;
            }
            //剩下两手牌时出绝对大牌
            if (handCardData.handCardValueList[17] > 0 && handCardData.handCardValueList[16] > 0)
            {
                handCardData.handCardValueList[17]--;
                handCardData.handCardValueList[16]--;
                handCardData.handCardsCount -= 2;
                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                handCardData.handCardValueList[17]++;
                handCardData.handCardValueList[16]++;
                handCardData.handCardsCount += 2;
                if (tmpHandCardValue.needRound == 1)
                {
                    handCardData.putCardList.Add(17);
                    handCardData.putCardList.Add(16);
                    handCardData.newCardGroupData =
                        CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_KING_CARD, 17, 2);
                    return;
                }
            }
            //暂存最佳的价值
            HandCardValue bestHandCardValue = new HandCardValue();
            bestHandCardValue.needRound = 20;
            bestHandCardValue.sumValue = UtilityConst.MinCardsValue;
            //不出牌默认增加一个轮次
            bestHandCardValue.needRound += 1;
            //暂存最佳组合
            CardGroupData bestCardGroupData = new CardGroupData();
            //带出去的牌
            int tmp_1 = 0;
            int tmp_2 = 0;
            int tmp_3 = 0;
            int tmp_4 = 0;
            //有限处理三牌、飞机等
            for (int i = 3; i < 16; i++)
            {
                if (handCardData.handCardValueList[i] != 4)
                {
                    /*//出三带一
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        handCardData.handCardValueList[i] -= 3;
                        for (int j = 3; j < 18; j++)
                        {
                            if (handCardData.handCardValueList[j] > 0)
                            {
                                handCardData.handCardValueList[j] -= 1;
                                handCardData.handCardsCount -= 4;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                handCardData.handCardValueList[j] += 1;
                                handCardData.handCardsCount += 4;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestCardGroupData =
                                        CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_TAKE_ONE, i, 4);
                                    tmp_1 = j;
                                }
                            }
                        }

                        handCardData.handCardValueList[i] += 3;
                    }

                    //出三带二
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        for (int j = 3; j < 16; j++)
                        {
                            handCardData.handCardValueList[i] -= 3;
                            if (handCardData.handCardValueList[j] > 1)
                            {
                                handCardData.handCardValueList[j] -= 2;
                                handCardData.handCardsCount -= 5;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                handCardData.handCardValueList[j] += 2;
                                handCardData.handCardsCount += 5;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestCardGroupData =
                                        CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_TAKE_TWO, i, 5);
                                    tmp_1 = j;
                                }
                            }
                            handCardData.handCardValueList[i] += 3;
                        }
                    }*/

                    //出三带一单连
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        int prov = 0;
                        for (int j = i; j < 15; j++)
                        {
                            if (handCardData.handCardValueList[j] > 2)
                            {
                                prov++;
                            }
                            else
                            {
                                break;
                            }

                            //二连飞机
                            if (prov == 2)
                            {
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] -= 3;
                                }

                                handCardData.handCardsCount -= prov * 4;
                                for (int tmp1 = 3; tmp1 < 18; tmp1++)
                                {
                                    if (handCardData.handCardValueList[tmp1] > 0)
                                    {
                                        handCardData.handCardValueList[tmp1] -= 1;
                                        for (int tmp2 = tmp1; tmp2 < 18; tmp2++)
                                        {
                                            if (handCardData.handCardValueList[tmp2] > 0)
                                            {
                                                handCardData.handCardValueList[tmp2] -= 1;
                                                HandCardValue tmpHandCardValue =
                                                    CardAlgorithm.GetHandCardValue(handCardData);
                                                //选取(总权值 - 轮次 * 7)最高的策略
                                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                                {
                                                    bestHandCardValue = tmpHandCardValue;
                                                    bestCardGroupData =
                                                        CardAlgorithm.GetCardGroupDataValue(
                                                            CardGroupType.CT_THREE_TAKE_ONE_LINE, j, prov * 4);
                                                    tmp_1 = tmp1;
                                                    tmp_2 = tmp2;
                                                }

                                                handCardData.handCardValueList[tmp2] += 1;
                                            }
                                        }

                                        handCardData.handCardValueList[tmp1] += 1;
                                    }
                                }

                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] += 3;
                                }

                                handCardData.handCardsCount += prov * 4;
                            }

                            //三连飞机
                            if (prov == 3)
                            {
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] -= 3;
                                }

                                handCardData.handCardsCount -= prov * 4;
                                for (int tmp1 = 3; tmp1 < 18; tmp1++)
                                {
                                    if (handCardData.handCardValueList[tmp1] > 0)
                                    {
                                        handCardData.handCardValueList[tmp1] -= 1;
                                        for (int tmp2 = tmp1; tmp2 < 18; tmp2++)
                                        {
                                            if (handCardData.handCardValueList[tmp2] > 0)
                                            {
                                                handCardData.handCardValueList[tmp2] -= 1;
                                                for (int tmp3 = tmp2; tmp3 < 18; tmp3++)
                                                {
                                                    if (handCardData.handCardValueList[tmp3] > 0)
                                                    {
                                                        handCardData.handCardValueList[tmp3] -= 1;
                                                        HandCardValue tmpHandCardValue =
                                                            CardAlgorithm.GetHandCardValue(handCardData);
                                                        //选取(总权值 - 轮次 * 7)最高的策略
                                                        if ((bestHandCardValue.sumValue -
                                                             (bestHandCardValue.needRound * 7)) <=
                                                            (tmpHandCardValue.sumValue -
                                                             (tmpHandCardValue.needRound * 7)))
                                                        {
                                                            bestHandCardValue = tmpHandCardValue;
                                                            bestCardGroupData =
                                                                CardAlgorithm.GetCardGroupDataValue(
                                                                    CardGroupType.CT_THREE_TAKE_ONE_LINE, j, prov * 4);
                                                            tmp_1 = tmp1;
                                                            tmp_2 = tmp2;
                                                            tmp_3 = tmp3;
                                                        }

                                                        handCardData.handCardValueList[tmp3] += 1;
                                                    }
                                                }

                                                handCardData.handCardValueList[tmp2] += 1;
                                            }
                                        }

                                        handCardData.handCardValueList[tmp1] += 1;
                                    }
                                }

                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] += 3;
                                }

                                handCardData.handCardsCount += prov * 4;
                            }

                            //四连飞机
                            if (prov == 4)
                            {
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] -= 3;
                                }

                                handCardData.handCardsCount -= prov * 4;
                                for (int tmp1 = 3; tmp1 < 18; tmp1++)
                                {
                                    if (handCardData.handCardValueList[tmp1] > 0)
                                    {
                                        handCardData.handCardValueList[tmp1] -= 1;
                                        for (int tmp2 = tmp1; tmp2 < 18; tmp2++)
                                        {
                                            if (handCardData.handCardValueList[tmp2] > 0)
                                            {
                                                handCardData.handCardValueList[tmp2] -= 1;
                                                for (int tmp3 = tmp2; tmp3 < 18; tmp3++)
                                                {
                                                    if (handCardData.handCardValueList[tmp3] > 0)
                                                    {
                                                        handCardData.handCardValueList[tmp3] -= 1;
                                                        for (int tmp4 = tmp3; tmp4 < 18; tmp4++)
                                                        {
                                                            if (handCardData.handCardValueList[tmp4] > 0)
                                                            {
                                                                handCardData.handCardValueList[tmp4] -= 1;
                                                                HandCardValue tmpHandCardValue =
                                                                    CardAlgorithm.GetHandCardValue(handCardData);
                                                                //选取(总权值 - 轮次 * 7)最高的策略
                                                                if ((bestHandCardValue.sumValue -
                                                                     (bestHandCardValue.needRound * 7)) <=
                                                                    (tmpHandCardValue.sumValue -
                                                                     (tmpHandCardValue.needRound * 7)))
                                                                {
                                                                    bestHandCardValue = tmpHandCardValue;
                                                                    bestCardGroupData =
                                                                        CardAlgorithm.GetCardGroupDataValue(
                                                                            CardGroupType.CT_THREE_TAKE_ONE_LINE, j,
                                                                            prov * 4);
                                                                    tmp_1 = tmp1;
                                                                    tmp_2 = tmp2;
                                                                    tmp_3 = tmp3;
                                                                    tmp_4 = tmp4;
                                                                }

                                                                handCardData.handCardValueList[tmp4] += 1;
                                                            }
                                                        }

                                                        handCardData.handCardValueList[tmp3] += 1;
                                                    }
                                                }

                                                handCardData.handCardValueList[tmp2] += 1;
                                            }
                                        }

                                        handCardData.handCardValueList[tmp1] += 1;
                                    }
                                }

                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] += 3;
                                }

                                handCardData.handCardsCount += prov * 4;
                            }
                        }
                    }

                    //出三带二连
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        int prov = 0;
                        for (int j = i; j < 15; j++)
                        {
                            if (handCardData.handCardValueList[j] > 2)
                            {
                                prov++;
                            }
                            else
                            {
                                break;
                            }

                            //二连飞机
                            if (prov == 2)
                            {
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] -= 3;
                                }

                                handCardData.handCardsCount -= prov * 5;
                                for (int tmp1 = 3; tmp1 < 16; tmp1++)
                                {
                                    if (handCardData.handCardValueList[tmp1] > 1)
                                    {
                                        handCardData.handCardValueList[tmp1] -= 2;
                                        for (int tmp2 = tmp1; tmp2 < 16; tmp2++)
                                        {
                                            if (handCardData.handCardValueList[tmp2] > 1)
                                            {
                                                handCardData.handCardValueList[tmp2] -= 2;
                                                HandCardValue tmpHandCardValue =
                                                    CardAlgorithm.GetHandCardValue(handCardData);
                                                //选取(总权值 - 轮次 * 7)最高的策略
                                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                                {
                                                    bestHandCardValue = tmpHandCardValue;
                                                    bestCardGroupData =
                                                        CardAlgorithm.GetCardGroupDataValue(
                                                            CardGroupType.CT_THREE_TAKE_TWO_LINE, j, prov * 5);
                                                    tmp_1 = tmp1;
                                                    tmp_2 = tmp2;
                                                }

                                                handCardData.handCardValueList[tmp2] += 2;
                                            }
                                        }

                                        handCardData.handCardValueList[tmp1] += 2;
                                    }
                                }

                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] += 3;
                                }

                                handCardData.handCardsCount += prov * 5;
                            }

                            //三连飞机
                            if (prov == 3)
                            {
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] -= 3;
                                }

                                handCardData.handCardsCount -= prov * 5;
                                for (int tmp1 = 3; tmp1 < 16; tmp1++)
                                {
                                    if (handCardData.handCardValueList[tmp1] > 1)
                                    {
                                        handCardData.handCardValueList[tmp1] -= 2;
                                        for (int tmp2 = tmp1; tmp2 < 16; tmp2++)
                                        {
                                            if (handCardData.handCardValueList[tmp2] > 1)
                                            {
                                                handCardData.handCardValueList[tmp2] -= 2;
                                                for (int tmp3 = tmp2; tmp3 < 16; tmp3++)
                                                {
                                                    if (handCardData.handCardValueList[tmp3] > 1)
                                                    {
                                                        handCardData.handCardValueList[tmp3] -= 2;
                                                        HandCardValue tmpHandCardValue =
                                                            CardAlgorithm.GetHandCardValue(handCardData);
                                                        //选取(总权值 - 轮次 * 7)最高的策略
                                                        if ((bestHandCardValue.sumValue -
                                                             (bestHandCardValue.needRound * 7)) <=
                                                            (tmpHandCardValue.sumValue -
                                                             (tmpHandCardValue.needRound * 7)))
                                                        {
                                                            bestHandCardValue = tmpHandCardValue;
                                                            bestCardGroupData =
                                                                CardAlgorithm.GetCardGroupDataValue(
                                                                    CardGroupType.CT_THREE_TAKE_TWO_LINE, j, prov * 5);
                                                            tmp_1 = tmp1;
                                                            tmp_2 = tmp2;
                                                            tmp_3 = tmp3;
                                                        }
                                                        handCardData.handCardValueList[tmp3] += 2;
                                                    }
                                                }
                                                handCardData.handCardValueList[tmp2] += 2;
                                            }
                                        }
                                        handCardData.handCardValueList[tmp1] += 2;
                                    }
                                }
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] += 3;
                                }
                                handCardData.handCardsCount += prov * 5;
                            }
                        }
                    }
                }
            }

            if (bestCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_ONE)
            {
                for (int i = 0; i < 3; i++)
                {
                    handCardData.putCardList.Add(bestCardGroupData.maxCard);
                }
                handCardData.putCardList.Add(tmp_1);
                handCardData.newCardGroupData = bestCardGroupData;
                return;
            }
            else if (bestCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_TWO)
            {
                for (int i = 0; i < 3; i++)
                {
                    handCardData.putCardList.Add(bestCardGroupData.maxCard);
                }
                handCardData.putCardList.Add(tmp_1);
                handCardData.putCardList.Add(tmp_1);
                handCardData.newCardGroupData = bestCardGroupData;
                return;
            }
            else if (bestCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_ONE_LINE)
            {
                for (int j = bestCardGroupData.maxCard - (bestCardGroupData.count / 4) + 1;
                     j <= bestCardGroupData.maxCard;
                     j++)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        handCardData.putCardList.Add(j);
                    }
                }
                if (bestCardGroupData.count / 4 == 2)
                {
                    handCardData.putCardList.Add(tmp_1);
                    handCardData.putCardList.Add(tmp_2);
                }
                if (bestCardGroupData.count / 4 == 3)
                {
                    handCardData.putCardList.Add(tmp_1);
                    handCardData.putCardList.Add(tmp_2);
                    handCardData.putCardList.Add(tmp_3);
                }
                if (bestCardGroupData.count / 4 == 4)
                {
                    handCardData.putCardList.Add(tmp_1);
                    handCardData.putCardList.Add(tmp_2);
                    handCardData.putCardList.Add(tmp_3);
                    handCardData.putCardList.Add(tmp_4);
                }
                handCardData.newCardGroupData = bestCardGroupData;
                return;
            }
            else if (bestCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_TWO_LINE)
            {
                for (int j = bestCardGroupData.maxCard - (bestCardGroupData.count / 5) + 1;
                     j <= bestCardGroupData.maxCard;
                     j++)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        handCardData.putCardList.Add(j);
                    }
                }
                if (bestCardGroupData.count / 5 == 2)
                {
                    handCardData.putCardList.Add(tmp_1);
                    handCardData.putCardList.Add(tmp_1);
                    handCardData.putCardList.Add(tmp_2);
                    handCardData.putCardList.Add(tmp_2);
                }
                if (bestCardGroupData.count / 5 == 3)
                {
                    handCardData.putCardList.Add(tmp_1);
                    handCardData.putCardList.Add(tmp_1);
                    handCardData.putCardList.Add(tmp_2);
                    handCardData.putCardList.Add(tmp_2);
                    handCardData.putCardList.Add(tmp_3);
                    handCardData.putCardList.Add(tmp_3);
                }
                handCardData.newCardGroupData = bestCardGroupData;
                return;
            }

            //次之处理当前价值最低的牌
            for (int i = 3; i < 16; i++)
            {
                if (handCardData.handCardValueList[i] != 0 && handCardData.handCardValueList[i] != 4)
                {
                    bool single = !(handCardData.selfTurn && handCardData.GetEnemyCardsCount() == 1);
                    if (!single)
                    {
                        XRLog.LogWarning("ss");
                    }
                    //出单牌
                    if (handCardData.handCardValueList[i] > 0 && single)
                    {
                        handCardData.handCardValueList[i]--;
                        handCardData.handCardsCount--;
                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                        handCardData.handCardValueList[i]++;
                        handCardData.handCardsCount++;
                        //选取(总权值 - 轮次 * 7)最高的策略
                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                        {
                            bestHandCardValue = tmpHandCardValue;
                            bestCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE, i, 1);
                        }
                    }
                    //出对牌
                    if (handCardData.handCardValueList[i] > 1)
                    {
                        handCardData.handCardValueList[i] -= 2;
                        handCardData.handCardsCount -= 2;
                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                        handCardData.handCardValueList[i] += 2;
                        handCardData.handCardsCount += 2;
                        //选取(总权值 - 轮次 * 7)最高的策略
                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                        {
                            bestHandCardValue = tmpHandCardValue;
                            bestCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_DOUBLE, i, 2);
                        }
                    }
                    //出三牌
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        handCardData.handCardValueList[i] -= 3;
                        handCardData.handCardsCount -= 3;
                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                        handCardData.handCardValueList[i] += 3;
                        handCardData.handCardsCount += 3;
                        //选取(总权值 - 轮次 * 7)最高的策略
                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                        {
                            bestHandCardValue = tmpHandCardValue;
                            bestCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE, i, 3);
                        }
                    }
                    //出单顺
                    if (handCardData.handCardValueList[i] > 0)
                    {
                        int prov = 0;
                        for (int j = i; j < 15; j++)
                        {
                            if (handCardData.handCardValueList[j] > 0)
                            {
                                prov++;
                            }
                            else
                            {
                                break;
                            }

                            if (prov >= 5)
                            {
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k]--;
                                }
                                handCardData.handCardsCount -= prov;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k]++;
                                }
                                handCardData.handCardsCount += prov;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE_LINE, j, prov);
                                }
                            }
                        }
                    }
                    //出双顺
                    if (handCardData.handCardValueList[i] > 1)
                    {
                        int prov = 0;
                        for (int j = i; j < 15; j++)
                        {
                            if (handCardData.handCardValueList[j] > 1)
                            {
                                prov++;
                            }
                            else
                            {
                                break;
                            }

                            if (prov >= 3)
                            {
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] -= 2;
                                }
                                handCardData.handCardsCount -= prov * 2;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] += 2;
                                }
                                handCardData.handCardsCount += prov * 2;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_DOUBLE_LINE, j, prov * 2);
                                }
                            }
                        }
                    }
                    //出三顺
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        int prov = 0;
                        for (int j = i; j < 15; j++)
                        {
                            if (handCardData.handCardValueList[j] > 2)
                            {
                                prov++;
                            }
                            else
                            {
                                break;
                            }

                            if (prov >= 2)
                            {
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] -= 3;
                                }
                                handCardData.handCardsCount -= prov * 3;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                for (int k = i; k <= j; k++)
                                {
                                    handCardData.handCardValueList[k] += 3;
                                }
                                handCardData.handCardsCount += prov * 3;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_LINE, j, prov * 3);
                                }
                            }
                        }
                    }

                    //出三带一
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        handCardData.handCardValueList[i] -= 3;
                        for (int j = 3; j < 18; j++)
                        {
                            if (handCardData.handCardValueList[j] > 0)
                            {
                                handCardData.handCardValueList[j] -= 1;
                                handCardData.handCardsCount -= 4;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                handCardData.handCardValueList[j] += 1;
                                handCardData.handCardsCount += 4;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestCardGroupData =
                                        CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_TAKE_ONE, i, 4);
                                    tmp_1 = j;
                                }
                            }
                        }

                        handCardData.handCardValueList[i] += 3;
                    }

                    //出三带二
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        for (int j = 3; j < 16; j++)
                        {
                            handCardData.handCardValueList[i] -= 3;
                            if (handCardData.handCardValueList[j] > 1)
                            {
                                handCardData.handCardValueList[j] -= 2;
                                handCardData.handCardsCount -= 5;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                handCardData.handCardValueList[j] += 2;
                                handCardData.handCardsCount += 5;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestCardGroupData =
                                        CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_TAKE_TWO, i, 5);
                                    tmp_1 = j;
                                }
                            }
                            handCardData.handCardValueList[i] += 3;
                        }
                    }

                    switch (bestCardGroupData.cgType)
                    {
                        case CardGroupType.CT_ERROR:
                            break;
                        case CardGroupType.CT_SINGLE:
                            handCardData.putCardList.Add(bestCardGroupData.maxCard);
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_DOUBLE:
                            for (int j = 0; j < 2; j++)
                            {
                                handCardData.putCardList.Add(bestCardGroupData.maxCard);
                            }
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_THREE:
                            for (int j = 0; j < 3; j++)
                            {
                                handCardData.putCardList.Add(bestCardGroupData.maxCard);
                            }
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_SINGLE_LINE:
                            for (int j = bestCardGroupData.maxCard - bestCardGroupData.count + 1; j <= bestCardGroupData.maxCard; j++)
                            {
                                handCardData.putCardList.Add(j);
                            }
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_DOUBLE_LINE:
                            for (int j = bestCardGroupData.maxCard - (bestCardGroupData.count / 2) + 1; j <= bestCardGroupData.maxCard; j++)
                            {
                                handCardData.putCardList.Add(j);
                                handCardData.putCardList.Add(j);
                            }
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_THREE_LINE:
                            for (int j = bestCardGroupData.maxCard - (bestCardGroupData.count / 3) + 1; j <= bestCardGroupData.maxCard; j++)
                            {
                                handCardData.putCardList.Add(j);
                                handCardData.putCardList.Add(j);
                                handCardData.putCardList.Add(j);
                            }
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_THREE_TAKE_ONE:
                            for (int j = 0; j < 3; j++)
                            {
                                handCardData.putCardList.Add(bestCardGroupData.maxCard);
                            }
                            handCardData.putCardList.Add(tmp_1);
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_THREE_TAKE_TWO:
                            for (int j = 0; j < 3; j++)
                            {
                                handCardData.putCardList.Add(bestCardGroupData.maxCard);
                            }
                            handCardData.putCardList.Add(tmp_1);
                            handCardData.putCardList.Add(tmp_1);
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_THREE_TAKE_ONE_LINE:
                            for (int j = bestCardGroupData.maxCard - (bestCardGroupData.count / 4) + 1;
                                j <= bestCardGroupData.maxCard;
                                j++)
                            {
                                for (int k = 0; k < 3; k++)
                                {
                                    handCardData.putCardList.Add(j);
                                }

                                if (bestCardGroupData.count / 4 == 2)
                                {
                                    handCardData.putCardList.Add(tmp_1);
                                    handCardData.putCardList.Add(tmp_2);
                                }
                                if (bestCardGroupData.count / 4 == 3)
                                {
                                    handCardData.putCardList.Add(tmp_1);
                                    handCardData.putCardList.Add(tmp_2);
                                    handCardData.putCardList.Add(tmp_3);
                                }
                                if (bestCardGroupData.count / 4 == 4)
                                {
                                    handCardData.putCardList.Add(tmp_1);
                                    handCardData.putCardList.Add(tmp_2);
                                    handCardData.putCardList.Add(tmp_3);
                                    handCardData.putCardList.Add(tmp_4);
                                }
                            }
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                        case CardGroupType.CT_THREE_TAKE_TWO_LINE:
                            for (int j = bestCardGroupData.maxCard - (bestCardGroupData.count / 5) + 1;
                                j <= bestCardGroupData.maxCard;
                                j++)
                            {
                                for (int k = 0; k < 3; k++)
                                {
                                    handCardData.putCardList.Add(j);
                                }

                                if (bestCardGroupData.count / 5 == 2)
                                {
                                    handCardData.putCardList.Add(tmp_1);
                                    handCardData.putCardList.Add(tmp_1);
                                    handCardData.putCardList.Add(tmp_2);
                                    handCardData.putCardList.Add(tmp_2);
                                }
                                if (bestCardGroupData.count / 5 == 3)
                                {
                                    handCardData.putCardList.Add(tmp_1);
                                    handCardData.putCardList.Add(tmp_1);
                                    handCardData.putCardList.Add(tmp_2);
                                    handCardData.putCardList.Add(tmp_2);
                                    handCardData.putCardList.Add(tmp_3);
                                    handCardData.putCardList.Add(tmp_3);
                                }
                            }
                            handCardData.newCardGroupData = bestCardGroupData;
                            return;
                    }
                    //return;
                }
            }

            //当地主或农民只剩1张牌且只能出单牌时，从大到小出
            for (int i = 16; i >= 3; i--)
            {
                if (handCardData.handCardValueList[i] != 0 && handCardData.handCardValueList[i] != 4)
                {
                    //出单牌
                    if (handCardData.handCardValueList[i] > 0)
                    {
                        //补丁1
                        bool patch1 = GetPutCardList_Active_Patch1(handCardData, bestHandCardValue, i,
                            bestCardGroupData);
                        //补丁2
                        bool patch2 = GetPutCardList_Active_Patch2(handCardData, bestHandCardValue, i,
                            bestCardGroupData);
                        if (patch1 || patch2)
                        {
                            bestCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE, i, 1);
                        }
                    }

                    if (bestCardGroupData.cgType == CardGroupType.CT_SINGLE)
                    {
                        handCardData.putCardList.Add(bestCardGroupData.maxCard);
                        handCardData.newCardGroupData = bestCardGroupData;
                        return;
                    }
                }
            }
            //如果没有3-2的非炸牌，则看有无单王
            if (handCardData.handCardValueList[16] == 1 && handCardData.handCardValueList[17] == 0)
            {
                handCardData.putCardList.Add(16);
                handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE, 16, 1);
                return;
            }
            if (handCardData.handCardValueList[16] == 0 && handCardData.handCardValueList[17] == 1)
            {
                handCardData.putCardList.Add(17);
                handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE, 17, 1);
                return;
            }
            //单王也没有，出炸弹
            for (int i = 3; i < 16; i++)
            {
                if (handCardData.handCardValueList[i] == 4)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        handCardData.putCardList.Add(i);
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_BOMB_CARD, i, 4);
                    return;
                }
            }
            //异常错误
            handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ERROR, 0, 0);
        }

        /// <summary>
        /// 获得出牌序列--被动出牌
        /// </summary>
        public static void GetPutCardList_Limit(HandCardData handCardData)
        {

            handCardData.ClearPutCardList();
            //只剩两手牌时，出王炸
            if (handCardData.handCardValueList[17] > 0 && handCardData.handCardValueList[16] > 0)
            {
                handCardData.handCardValueList[17]--;
                handCardData.handCardValueList[16]--;
                handCardData.handCardsCount -= 2;
                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                handCardData.handCardValueList[17]++;
                handCardData.handCardValueList[16]++;
                handCardData.handCardsCount += 2;
                if (tmpHandCardValue.needRound == 1)
                {
                    handCardData.putCardList.Add(17);
                    handCardData.putCardList.Add(16);
                    handCardData.newCardGroupData =
                        CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_KING_CARD, 17, 2);
                    return;
                }
            }
            //错误牌型--不出
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_ERROR)
            {
                handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ERROR, 0, 0);
                return;
            }

            //不出牌型--不出
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_ZERO)
            {
                handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ERROR, 0, 0);
                return;
            }

            //补丁1
            bool patch1 = GetPutCardList_Limit_Patch1(handCardData);
            if (patch1)
            {
                handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ZERO, 0, 0);
                return;
            }
            //单牌牌型
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_SINGLE)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_SINGLE &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }
                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //是否要出牌
                bool putCards = false;
                //补丁3
                bool patch3 = GetPutCardList_Limit_Patch3(handCardData, bestHandCardValue, ref bestMaxCard, ref putCards);
                //补丁4
                bool patch4 = GetPutCardList_Limit_Patch4(handCardData, bestHandCardValue, ref bestMaxCard, ref putCards);
                if (!patch3 && !patch4)
                {
                    for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 18; i++)
                    {
                        if (handCardData.handCardValueList[i] > 0)
                        {
                            //尝试打出一张牌，并估算剩余的手牌价值
                            handCardData.handCardValueList[i]--;
                            handCardData.handCardsCount--;
                            HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                            handCardData.handCardValueList[i]++;
                            handCardData.handCardsCount++;

                            //选取(总权值 - 轮次 * 7)最高的策略
                            if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                            {
                                bestHandCardValue = tmpHandCardValue;
                                bestMaxCard = i;
                                putCards = true;
                            }
                        }
                    }
                }

                if (putCards)
                {
                    bool patch2 = GetPutCardList_Limit_Patch2(handCardData, bestMaxCard);
                    //如果压自家的牌太大则pass
                    if (patch2)
                    {
                        handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ZERO, 0, 0);
                        return;
                    }
                    handCardData.putCardList.Add(bestMaxCard);
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE, bestMaxCard, 1);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //对牌牌型
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_DOUBLE)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_DOUBLE &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }

                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 18; i++)
                {
                    if (handCardData.handCardValueList[i] > 1)
                    {
                        //尝试打出一张牌，并估算剩余的手牌价值
                        handCardData.handCardValueList[i] -= 2;
                        handCardData.handCardsCount -= 2;
                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                        handCardData.handCardValueList[i] += 2;
                        handCardData.handCardsCount += 2;

                        //选取(总权值 - 轮次 * 7)最高的策略
                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                        {
                            bestHandCardValue = tmpHandCardValue;
                            bestMaxCard = i;
                            putCards = true;
                        }
                    }
                }

                if (putCards)
                {
                    bool patch2 = GetPutCardList_Limit_Patch2(handCardData, bestMaxCard);
                    //如果压自家的牌太大则pass
                    if (patch2)
                    {
                        handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ZERO, 0, 0);
                        return;
                    }
                    handCardData.putCardList.Add(bestMaxCard);
                    handCardData.putCardList.Add(bestMaxCard);
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_DOUBLE, bestMaxCard, 2);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //三条牌型
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_THREE)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_THREE &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }

                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 18; i++)
                {
                    if (handCardData.handCardValueList[i] > 1)
                    {
                        //尝试打出一张牌，并估算剩余的手牌价值
                        handCardData.handCardValueList[i] -= 3;
                        handCardData.handCardsCount -= 3;
                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                        handCardData.handCardValueList[i] += 3;
                        handCardData.handCardsCount += 3;

                        //选取(总权值 - 轮次 * 7)最高的策略
                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                        {
                            bestHandCardValue = tmpHandCardValue;
                            bestMaxCard = i;
                            putCards = true;
                        }
                    }
                }

                if (putCards)
                {
                    handCardData.putCardList.Add(bestMaxCard);
                    handCardData.putCardList.Add(bestMaxCard);
                    handCardData.putCardList.Add(bestMaxCard);
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE, bestMaxCard, 3);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //单连牌型
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_SINGLE_LINE)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_SINGLE_LINE &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard &&
                        surCardGroupData.count == GameSituationControl.I.newCardGroupData.count)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }
                //顺子的标志
                int prov = 0;
                //顺子起点
                int start = 0;
                //顺子终点
                int end = 0;
                //顺子长度
                int length = GameSituationControl.I.newCardGroupData.count;

                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard - length + 2; i < 15; i++)
                {
                    if (handCardData.handCardValueList[i] > 0)
                    {
                        prov++;
                    }
                    else
                    {
                        prov = 0;
                    }

                    if (prov >= length)
                    {
                        end = i;
                        start = i - length + 1;
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j]--;
                        }
                        handCardData.handCardsCount -= GameSituationControl.I.newCardGroupData.count;
                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j]++;
                        }
                        handCardData.handCardsCount += GameSituationControl.I.newCardGroupData.count;
                        //选取(总权值 - 轮次 * 7)最高的策略
                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                        {
                            bestHandCardValue = tmpHandCardValue;
                            bestMaxCard = i;
                            putCards = true;
                        }
                    }
                }

                if (putCards)
                {
                    for (int j = start; j <= end; j++)
                    {
                        handCardData.putCardList.Add(j);
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE_LINE, bestMaxCard, GameSituationControl.I.newCardGroupData.count);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //对连牌型
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_DOUBLE_LINE)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_DOUBLE_LINE &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard &&
                        surCardGroupData.count == GameSituationControl.I.newCardGroupData.count)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }
                //顺子的标志
                int prov = 0;
                //顺子起点
                int start = 0;
                //顺子终点
                int end = 0;
                //顺子长度
                int length = GameSituationControl.I.newCardGroupData.count;

                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard - length + 2; i < 15; i++)
                {
                    if (handCardData.handCardValueList[i] > 1)
                    {
                        prov++;
                    }
                    else
                    {
                        prov = 0;
                    }

                    if (prov >= length)
                    {
                        end = i;
                        start = i - length + 1;
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j] -= 2;
                        }
                        handCardData.handCardsCount -= GameSituationControl.I.newCardGroupData.count;
                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j] += 2;
                        }
                        handCardData.handCardsCount += GameSituationControl.I.newCardGroupData.count;
                        //选取(总权值 - 轮次 * 7)最高的策略
                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                        {
                            bestHandCardValue = tmpHandCardValue;
                            bestMaxCard = i;
                            putCards = true;
                        }
                    }
                }

                if (putCards)
                {
                    for (int j = start; j <= end; j++)
                    {
                        handCardData.putCardList.Add(j);
                        handCardData.putCardList.Add(j);
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE_LINE, bestMaxCard, GameSituationControl.I.newCardGroupData.count);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //三连牌型
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_THREE_LINE)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_THREE_LINE &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard &&
                        surCardGroupData.count == GameSituationControl.I.newCardGroupData.count)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }
                //顺子的标志
                int prov = 0;
                //顺子起点
                int start = 0;
                //顺子终点
                int end = 0;
                //顺子长度
                int length = GameSituationControl.I.newCardGroupData.count;

                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard - length + 2; i < 15; i++)
                {
                    if (handCardData.handCardValueList[i] > 0)
                    {
                        prov++;
                    }
                    else
                    {
                        prov = 0;
                    }

                    if (prov >= length)
                    {
                        end = i;
                        start = i - length + 1;
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j]--;
                        }
                        handCardData.handCardsCount -= GameSituationControl.I.newCardGroupData.count;
                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j]++;
                        }
                        handCardData.handCardsCount += GameSituationControl.I.newCardGroupData.count;
                        //选取(总权值 - 轮次 * 7)最高的策略
                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                        {
                            bestHandCardValue = tmpHandCardValue;
                            bestMaxCard = i;
                            putCards = true;
                        }
                    }
                }

                if (putCards)
                {
                    for (int j = start; j <= end; j++)
                    {
                        handCardData.putCardList.Add(j);
                        handCardData.putCardList.Add(j);
                        handCardData.putCardList.Add(j);
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_SINGLE_LINE, bestMaxCard, GameSituationControl.I.newCardGroupData.count);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //三带一单
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_ONE)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_ONE &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }
                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //顺带出去的牌
                int tmp = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 16; i++)
                {
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        for (int j = 3; j < 18; j++)
                        {
                            //选出1张以上的牌且不是三张的那个牌
                            if (handCardData.handCardValueList[j] > 0 && j != i)
                            {
                                handCardData.handCardValueList[i] -= 3;
                                handCardData.handCardValueList[j] -= 1;
                                handCardData.handCardsCount -= 4;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                handCardData.handCardValueList[i] += 3;
                                handCardData.handCardValueList[j] += 1;
                                handCardData.handCardsCount += 4;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestMaxCard = i;
                                    tmp = j;
                                    putCards = true;
                                }
                            }
                        }
                    }
                }

                if (putCards)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        handCardData.putCardList.Add(bestMaxCard);
                    }
                    handCardData.putCardList.Add(tmp);
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_TAKE_ONE, bestMaxCard, 4);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //三带一对
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_TWO)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_TWO &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }
                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //顺带出去的牌
                int tmp = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 16; i++)
                {
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        for (int j = 3; j < 16; j++)
                        {
                            //选出2张以上的牌且不是三张的那个牌
                            if (handCardData.handCardValueList[j] > 1 && j != i)
                            {
                                handCardData.handCardValueList[i] -= 3;
                                handCardData.handCardValueList[j] -= 2;
                                handCardData.handCardsCount -= 5;
                                HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                handCardData.handCardValueList[i] += 3;
                                handCardData.handCardValueList[j] += 2;
                                handCardData.handCardsCount += 5;
                                //选取(总权值 - 轮次 * 7)最高的策略
                                if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                    (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                {
                                    bestHandCardValue = tmpHandCardValue;
                                    bestMaxCard = i;
                                    tmp = j;
                                    putCards = true;
                                }
                            }
                        }
                    }
                }

                if (putCards)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        handCardData.putCardList.Add(bestMaxCard);
                    }
                    for (int i = 0; i < 2; i++)
                    {
                        handCardData.putCardList.Add(tmp);
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_TAKE_TWO, bestMaxCard, 5);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //三带一单连
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_ONE_LINE)
            {
                //暂存最佳价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌让一个轮次
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //是否出牌的标志
                bool putCards = false;
                //验证顺子的标志
                int prov = 0;
                //顺子起点
                int start = 0;
                //顺子终点
                int end = 0;
                //顺子长度
                int length = GameSituationControl.I.newCardGroupData.count / 4;

                int tmp_1 = 0;
                int tmp_2 = 0;
                int tmp_3 = 0;
                int tmp_4 = 0;
                //2与王不参与顺子
                for (int i = GameSituationControl.I.newCardGroupData.maxCard - length + 2; i < 15; i++)
                {
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        prov++;
                    }
                    else
                    {
                        prov = 0;
                    }

                    if (prov >= length)
                    {
                        end = i;
                        start = i - length + 1;
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j] -= 3;
                        }
                        handCardData.handCardsCount -= GameSituationControl.I.newCardGroupData.count;
                        //分支处理
                        //二连飞机
                        if (length == 2)
                        {
                            for (int j = 3; j < 18; j++)
                            {
                                if (handCardData.handCardValueList[j] > 0)
                                {
                                    handCardData.handCardValueList[j] -= 1;
                                    for (int k = 3; k < 18; k++)
                                    {
                                        if (handCardData.handCardValueList[k] > 0)
                                        {
                                            handCardData.handCardValueList[k] -= 1;
                                            HandCardValue tmpHandCardValue =
                                                CardAlgorithm.GetHandCardValue(handCardData);
                                            handCardData.handCardValueList[k] += 1;
                                            //选取总权值-轮次*7最高的策略
                                            if (bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7) <=
                                                tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7))
                                            {
                                                bestHandCardValue = tmpHandCardValue;
                                                bestMaxCard = end;
                                                tmp_1 = j;
                                                tmp_2 = k;
                                                putCards = true;
                                            }
                                        }
                                    }
                                    handCardData.handCardValueList[j] += 1;
                                }
                            }
                        }
                        //三连飞机
                        if (length == 3)
                        {
                            for (int j = 3; j < 18; j++)
                            {
                                if (handCardData.handCardValueList[j] > 0)
                                {
                                    handCardData.handCardValueList[j] -= 1;
                                    for (int k = 3; k < 18; k++)
                                    {
                                        if (handCardData.handCardValueList[k] > 0)
                                        {
                                            handCardData.handCardValueList[k] -= 1;
                                            for (int l = 3; l < 18; l++)
                                            {
                                                if (handCardData.handCardValueList[l] > 0)
                                                {
                                                    handCardData.handCardValueList[l] -= 1;
                                                    HandCardValue tmpHandCardValue =
                                                        CardAlgorithm.GetHandCardValue(handCardData);
                                                    handCardData.handCardValueList[l] += 1;
                                                    //选取总权值-轮次*7最高的策略
                                                    if (bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7) <=
                                                        tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7))
                                                    {
                                                        bestHandCardValue = tmpHandCardValue;
                                                        bestMaxCard = end;
                                                        tmp_1 = j;
                                                        tmp_2 = k;
                                                        tmp_3 = l;
                                                        putCards = true;
                                                    }
                                                }
                                            }
                                            handCardData.handCardValueList[k] += 1;
                                        }
                                    }
                                    handCardData.handCardValueList[j] += 1;
                                }
                            }
                        }
                        //四连飞机
                        if (length == 4)
                        {
                            for (int j = 3; j < 18; j++)
                            {
                                if (handCardData.handCardValueList[j] > 0)
                                {
                                    handCardData.handCardValueList[j] -= 1;
                                    for (int k = 3; k < 18; k++)
                                    {
                                        if (handCardData.handCardValueList[k] > 0)
                                        {
                                            handCardData.handCardValueList[k] -= 1;
                                            for (int l = 3; l < 18; l++)
                                            {
                                                if (handCardData.handCardValueList[l] > 0)
                                                {
                                                    handCardData.handCardValueList[l] -= 1;
                                                    for (int m = 3; m < 18; m++)
                                                    {
                                                        if (handCardData.handCardValueList[m] > 0)
                                                        {
                                                            handCardData.handCardValueList[m] -= 1;
                                                            HandCardValue tmpHandCardValue =
                                                                CardAlgorithm.GetHandCardValue(handCardData);
                                                            //选取总权值-轮次*7最高的策略
                                                            if (bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7) <=
                                                                tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7))
                                                            {
                                                                bestHandCardValue = tmpHandCardValue;
                                                                bestMaxCard = end;
                                                                tmp_1 = j;
                                                                tmp_2 = k;
                                                                tmp_3 = l;
                                                                tmp_4 = m;
                                                                putCards = true;
                                                            }
                                                            handCardData.handCardValueList[m] += 1;
                                                        }
                                                    }
                                                    handCardData.handCardValueList[l] += 1;
                                                }
                                            }
                                            handCardData.handCardValueList[k] += 1;
                                        }
                                    }
                                    handCardData.handCardValueList[j] += 1;
                                }
                            }
                        }
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j] += 3;
                        }
                        handCardData.handCardsCount += GameSituationControl.I.newCardGroupData.count;
                    }
                }

                if (putCards)
                {
                    for (int j = start; j <= end; j++)
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            handCardData.putCardList.Add(j);
                        }
                    }

                    if (length == 2)
                    {
                        handCardData.putCardList.Add(tmp_1);
                        handCardData.putCardList.Add(tmp_2);
                    }
                    if (length == 3)
                    {
                        handCardData.putCardList.Add(tmp_1);
                        handCardData.putCardList.Add(tmp_2);
                        handCardData.putCardList.Add(tmp_3);
                    }
                    if (length == 4)
                    {
                        handCardData.putCardList.Add(tmp_1);
                        handCardData.putCardList.Add(tmp_2);
                        handCardData.putCardList.Add(tmp_3);
                        handCardData.putCardList.Add(tmp_4);
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_TAKE_ONE_LINE, bestMaxCard, GameSituationControl.I.newCardGroupData.count);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //三带一对连
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_THREE_TAKE_TWO_LINE)
            {
                //暂存最佳价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //不出牌让一个轮次
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //是否出牌的标志
                bool putCards = false;
                //验证顺子的标志
                int prov = 0;
                //顺子起点
                int start = 0;
                //顺子终点
                int end = 0;
                //顺子长度
                int length = GameSituationControl.I.newCardGroupData.count / 5;

                int tmp_1 = 0;
                int tmp_2 = 0;
                int tmp_3 = 0;
                //2与王不参与顺子
                for (int i = GameSituationControl.I.newCardGroupData.maxCard - length + 2; i < 15; i++)
                {
                    if (handCardData.handCardValueList[i] > 2)
                    {
                        prov++;
                    }
                    else
                    {
                        prov = 0;
                    }

                    if (prov >= length)
                    {
                        end = i;
                        start = i - length + 1;
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j] -= 3;
                        }
                        handCardData.handCardsCount -= GameSituationControl.I.newCardGroupData.count;
                        //分支处理
                        //二连飞机
                        if (length == 2)
                        {
                            for (int j = 3; j < 18; j++)
                            {
                                if (handCardData.handCardValueList[j] > 0)
                                {
                                    handCardData.handCardValueList[j] -= 1;
                                    for (int k = 3; k < 18; k++)
                                    {
                                        if (handCardData.handCardValueList[k] > 1)
                                        {
                                            handCardData.handCardValueList[k] -= 2;
                                            HandCardValue tmpHandCardValue =
                                                CardAlgorithm.GetHandCardValue(handCardData);
                                            handCardData.handCardValueList[k] += 2;
                                            //选取总权值-轮次*7最高的策略
                                            if (bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7) <=
                                                tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7))
                                            {
                                                bestHandCardValue = tmpHandCardValue;
                                                bestMaxCard = end;
                                                tmp_1 = j;
                                                tmp_2 = k;
                                                putCards = true;
                                            }
                                        }
                                    }
                                    handCardData.handCardValueList[j] += 2;
                                }
                            }
                        }
                        //三连飞机
                        if (length == 3)
                        {
                            for (int j = 3; j < 18; j++)
                            {
                                if (handCardData.handCardValueList[j] > 1)
                                {
                                    handCardData.handCardValueList[j] -= 2;
                                    for (int k = 3; k < 18; k++)
                                    {
                                        if (handCardData.handCardValueList[k] > 1)
                                        {
                                            handCardData.handCardValueList[k] -= 2;
                                            for (int l = 3; l < 18; l++)
                                            {
                                                if (handCardData.handCardValueList[l] > 1)
                                                {
                                                    handCardData.handCardValueList[l] -= 2;
                                                    HandCardValue tmpHandCardValue =
                                                        CardAlgorithm.GetHandCardValue(handCardData);
                                                    handCardData.handCardValueList[l] += 2;
                                                    //选取总权值-轮次*7最高的策略
                                                    if (bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7) <=
                                                        tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7))
                                                    {
                                                        bestHandCardValue = tmpHandCardValue;
                                                        bestMaxCard = end;
                                                        tmp_1 = j;
                                                        tmp_2 = k;
                                                        tmp_3 = l;
                                                        putCards = true;
                                                    }
                                                }
                                            }
                                            handCardData.handCardValueList[k] += 2;
                                        }
                                    }
                                    handCardData.handCardValueList[j] += 2;
                                }
                            }
                        }
                        for (int j = start; j <= end; j++)
                        {
                            handCardData.handCardValueList[j] += 3;
                        }
                        handCardData.handCardsCount += GameSituationControl.I.newCardGroupData.count;
                    }
                }

                if (putCards)
                {
                    for (int j = start; j <= end; j++)
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            handCardData.putCardList.Add(j);
                        }
                    }
                    if (length == 2)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            handCardData.putCardList.Add(tmp_1);
                            handCardData.putCardList.Add(tmp_2);
                        }
                    }
                    if (length == 3)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            handCardData.putCardList.Add(tmp_1);
                            handCardData.putCardList.Add(tmp_2);
                            handCardData.putCardList.Add(tmp_3);
                        }
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_THREE_TAKE_TWO_LINE, bestMaxCard, GameSituationControl.I.newCardGroupData.count);
                    return;
                }
                //炸弹压制
                var boom = PutBoomCards(handCardData, bestHandCardValue, bestMaxCard, ref putCards);
                if (boom) return;
            }

            //四带二单
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_FOUR_TAKE_ONE)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_FOUR_TAKE_ONE &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }
                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //如果牌型的价值大于14--四带多最多可以提高14的价值，直接炸弹
                if (bestHandCardValue.sumValue > 14)
                {
                    //炸弹压制
                    var boom2 = PutBoomForFourCards(bestHandCardValue, handCardData);
                    if (boom2) return;
                }

                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //顺带出去的牌
                int tmp_1 = 0;
                int tmp_2 = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 16; i++)
                {
                    if (handCardData.handCardValueList[i] == 4)
                    {
                        for (int j = 3; j < 18; j++)
                        {
                            //选出1张以上的牌且不是四张的那个牌
                            if (handCardData.handCardValueList[j] > 0 && j != i)
                            {
                                for (int k = j; k < 18; k++)
                                {
                                    if (((k == j && handCardData.handCardValueList[k] > 1) || handCardData.handCardValueList[k] > 0)
                                        && k != i)
                                    {
                                        handCardData.handCardValueList[i] -= 4;
                                        handCardData.handCardValueList[j] -= 1;
                                        handCardData.handCardValueList[k] -= 1;
                                        handCardData.handCardsCount -= 6;
                                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                        handCardData.handCardValueList[i] += 4;
                                        handCardData.handCardValueList[j] += 1;
                                        handCardData.handCardValueList[k] += 1;
                                        handCardData.handCardsCount += 6;
                                        //选取(总权值 - 轮次 * 7)最高的策略
                                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                        {
                                            bestHandCardValue = tmpHandCardValue;
                                            bestMaxCard = i;
                                            tmp_1 = j;
                                            tmp_2 = k;
                                            putCards = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (putCards)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        handCardData.putCardList.Add(bestMaxCard);
                    }
                    handCardData.putCardList.Add(tmp_1);
                    handCardData.putCardList.Add(tmp_2);
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_FOUR_TAKE_ONE, bestMaxCard, 6);
                    return;
                }
                //炸弹压制
                var boom = PutBoomForFourCards(bestHandCardValue, handCardData);
                if (boom) return;
            }

            //四带二对
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_FOUR_TAKE_TWO)
            {
                //剪枝：如果能出最后一手牌就直接出
                CardGroupData surCardGroupData = CardAlgorithm.JudgeIsOneRoundCardData(handCardData.handCardValueList);
                if (surCardGroupData.cgType != CardGroupType.CT_ERROR)
                {
                    if (surCardGroupData.cgType == CardGroupType.CT_FOUR_TAKE_TWO &&
                        surCardGroupData.maxCard > GameSituationControl.I.newCardGroupData.maxCard)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                    else if (surCardGroupData.cgType is CardGroupType.CT_BOMB_CARD or CardGroupType.CT_KING_CARD)
                    {
                        PutAllHandCards(handCardData, surCardGroupData);
                        return;
                    }
                }
                //暂存最佳的价值
                HandCardValue bestHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //如果牌型的价值大于14--四带多最多可以提高14的价值，直接炸弹
                if (bestHandCardValue.sumValue > 14)
                {
                    //炸弹压制
                    var boom1 = PutBoomForFourCards(bestHandCardValue, handCardData);
                    if (boom1) return;
                }

                //不出牌的话轮次加1
                bestHandCardValue.needRound += 1;
                //暂存最佳牌号
                int bestMaxCard = 0;
                //顺带出去的牌
                int tmp_1 = 0;
                int tmp_2 = 0;
                //是否要出牌
                bool putCards = false;

                for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 16; i++)
                {
                    if (handCardData.handCardValueList[i] == 4)
                    {
                        for (int j = 3; j < 18; j++)
                        {
                            //选出2张以上的牌且不是四张的那个牌
                            if (handCardData.handCardValueList[j] > 1 && j != i)
                            {
                                for (int k = j + 1; k < 18; k++)
                                {
                                    if (handCardData.handCardValueList[k] > 1 && k != i)
                                    {
                                        handCardData.handCardValueList[i] -= 4;
                                        handCardData.handCardValueList[j] -= 2;
                                        handCardData.handCardValueList[k] -= 2;
                                        handCardData.handCardsCount -= 8;
                                        HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                                        handCardData.handCardValueList[i] += 4;
                                        handCardData.handCardValueList[j] += 2;
                                        handCardData.handCardValueList[k] += 2;
                                        handCardData.handCardsCount += 8;
                                        //选取(总权值 - 轮次 * 7)最高的策略
                                        if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                                            (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                                        {
                                            bestHandCardValue = tmpHandCardValue;
                                            bestMaxCard = i;
                                            tmp_1 = j;
                                            tmp_2 = k;
                                            putCards = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (putCards)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        handCardData.putCardList.Add(bestMaxCard);
                    }
                    for (int i = 0; i < 2; i++)
                    {
                        handCardData.putCardList.Add(tmp_1);
                        handCardData.putCardList.Add(tmp_2);
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_FOUR_TAKE_TWO, bestMaxCard, 8);
                    return;
                }
                //炸弹压制
                var boom = PutBoomForFourCards(bestHandCardValue, handCardData);
                if (boom) return;
            }

            //炸弹
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_BOMB_CARD)
            {
                for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 16; i++)
                {
                    if (handCardData.handCardValueList[i] == 4)
                    {
                        for (int j = 0; j < 4; j++)
                        {
                            handCardData.putCardList.Add(i);
                        }
                        handCardData.newCardGroupData =
                            CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_BOMB_CARD, i, 4);
                    }
                }
                //王炸
                if (handCardData.handCardValueList[17] > 0 && handCardData.handCardValueList[16] > 0)
                {
                    handCardData.putCardList.Add(17);
                    handCardData.putCardList.Add(16);
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_KING_CARD, 17, 2);
                    return;
                }
            }

            //王炸--不出
            if (GameSituationControl.I.newCardGroupData.cgType == CardGroupType.CT_KING_CARD)
            {
                handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ZERO, 0, 0);
                return;
            }
            handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_ZERO, 0, 0);
        }

        /// <summary>
        /// 打出所有手牌
        /// </summary>
        /// <param name="gameSituation"></param>
        /// <param name="handCardData"></param>
        /// <param name="surCardGroupData"></param>
        private static void PutAllHandCards(HandCardData handCardData,
            CardGroupData surCardGroupData)
        {
            //全部出完
            for (int i = 0; i < 18; i++)
            {
                for (int j = 0; j < handCardData.handCardValueList[i]; j++)
                {
                    handCardData.putCardList.Add(i);
                }
            }

            handCardData.newCardGroupData = surCardGroupData;
        }


        /// <summary>
        /// 使用炸弹压制
        /// </summary>
        /// <param name="gameSituation"></param>
        /// <param name="handCardData"></param>
        /// <param name="surCardGroupData"></param>
        /// <param name="bestHandCardValue"></param>
        /// <param name="bestMaxCard"></param>
        /// <param name="putCards"></param>
        private static bool PutBoomCards(HandCardData handCardData,
             HandCardValue bestHandCardValue, int bestMaxCard, ref bool putCards)
        {
            //农民自家直接返回
            if (handCardData.gameRole != GameRole.Landlord &&
                GameSituationControl.I.cardDroit != GameSituationControl.I.landlordId) return false;
            for (int i = 3; i < 16; i++)
            {
                if (handCardData.handCardValueList[i] == 4)
                {
                    //尝试打出炸弹
                    handCardData.handCardValueList[i] -= 4;
                    handCardData.handCardsCount -= 4;
                    HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                    handCardData.handCardValueList[i] += 4;
                    handCardData.handCardsCount += 4;
                    //选取总权值-轮次*7值最高的策略  或者 手牌价值为正表示手牌不错
                    if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) <=
                        (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)) || tmpHandCardValue.sumValue > 0)
                    {
                        bestHandCardValue = tmpHandCardValue;
                        bestMaxCard = i;
                        putCards = true;
                    }
                }
            }

            if (putCards)
            {
                for (int i = 0; i < 4; i++)
                {
                    handCardData.putCardList.Add(bestMaxCard);
                }
                handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_BOMB_CARD, bestMaxCard, 4);
                return true;
            }
            //王炸
            if (handCardData.handCardValueList[17] > 0 && handCardData.handCardValueList[16] > 0)
            {
                if (bestHandCardValue.sumValue > 24)
                {
                    handCardData.putCardList.Add(17);
                    handCardData.putCardList.Add(16);
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_KING_CARD, 17, 2);
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 针对4带多的牌型，可以打出炸弹
        /// </summary>
        /// <param name="bestHandCardValue"></param>
        /// <param name="handCardData"></param>
        /// <param name="gameSituation"></param>
        private static bool PutBoomForFourCards(HandCardValue bestHandCardValue, HandCardData handCardData)
        {
            for (int i = 3; i < 16; i++)
            {
                if (handCardData.handCardValueList[i] == 4)
                {
                    for (int j = 0; j < 4; i++)
                    {
                        handCardData.putCardList.Add(i);
                    }
                    handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_BOMB_CARD, i, 4);
                    return true;
                }
            }

            //王炸
            if (handCardData.handCardValueList[17] > 0 && handCardData.handCardValueList[16] > 0)
            {
                handCardData.putCardList.Add(17);
                handCardData.putCardList.Add(16);
                handCardData.newCardGroupData = CardAlgorithm.GetCardGroupDataValue(CardGroupType.CT_KING_CARD, 17, 2);
                return true;
            }
            return false;
        }

        /// <summary>
        /// 被动出牌时,自己手牌价值很低时避免乱压牌
        /// </summary>
        private static bool GetPutCardList_Limit_Patch1(HandCardData handCardData)
        {
            //农民自家
            if (handCardData.gameRole != GameRole.Landlord &&
                GameSituationControl.I.cardDroit != GameSituationControl.I.landlordId)
            {
                handCardData.handCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //如果回合数小于5，正常出牌
                if (handCardData.handCardValue.Value.needRound < 5) return false;
                //读取农民出的牌值
                CardGroupData newCardGroupData = GameSituationControl.I.newCardGroupData;
                //
                if (newCardGroupData.cgType != CardGroupType.CT_SINGLE &&
                    newCardGroupData.cgType != CardGroupType.CT_DOUBLE && handCardData.handCardValue.Value.sumValue < 5)
                {
                    int temp = newCardGroupData.maxCard;
                    //不是很大正常出牌
                    return temp > 13;
                }
            }
            return false;
        }

        /// <summary>
        /// 被动出牌时避免压队友牌太大
        /// </summary>
        /// <param name="handCardData"></param>
        /// <param name="bestHandCardValue"></param>
        /// <returns></returns>
        private static bool GetPutCardList_Limit_Patch2(HandCardData handCardData, int bestMaxCard)
        {
            if (handCardData.GetEnemyCardsCount() < 2) return false;
            //农民自家
            if (handCardData.gameRole != GameRole.Landlord &&
                GameSituationControl.I.cardDroit != GameSituationControl.I.landlordId)
            {
                handCardData.handCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                //如果回合数小于5，正常出牌
                if (handCardData.handCardValue.Value.needRound < 5) return false;
                if (bestMaxCard > 14 && GameSituationControl.I.newCardGroupData.maxCard > 12) return true;
            }
            return false;
        }

        /// <summary>
        /// 被动出牌时，地主只剩一张牌，农民上家从大到小出
        /// </summary>
        /// <param name="handCardData"></param>
        /// <param name="bestHandCardValue"></param>
        /// <param name="bestMaxCard"></param>
        /// <param name="putCards"></param>
        /// <returns></returns>
        private static bool GetPutCardList_Limit_Patch3(HandCardData handCardData, HandCardValue bestHandCardValue, ref int bestMaxCard, ref bool putCards)
        {
            //农民上家
            if (handCardData.gameRole == GameRole.PeasantTop)
            {
                //地主只剩一张牌，从大到小出
                if (handCardData.selfTurn && handCardData.GetEnemyCardsCount() < 2)
                {
                    bestHandCardValue.sumValue = int.MaxValue;
                    for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 18; i++)
                    {
                        if (handCardData.handCardValueList[i] > 0)
                        {
                            //尝试打出一张牌，并估算剩余的手牌价值
                            handCardData.handCardValueList[i]--;
                            handCardData.handCardsCount--;
                            HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                            handCardData.handCardValueList[i]++;
                            handCardData.handCardsCount++;

                            //选取(总权值 - 轮次 * 7)最高的策略
                            if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) >=
                                (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                            {
                                bestHandCardValue = tmpHandCardValue;
                                bestMaxCard = i;
                                putCards = true;
                            }
                        }
                    }
                    return putCards;
                }
            }
            return putCards;
        }

        /// <summary>
        /// 被动出牌时，农民只剩一张牌，地主从大到小出
        /// </summary>
        /// <param name="handCardData"></param>
        /// <param name="bestHandCardValue"></param>
        /// <param name="bestMaxCard"></param>
        /// <param name="putCards"></param>
        /// <returns></returns>
        private static bool GetPutCardList_Limit_Patch4(HandCardData handCardData, HandCardValue bestHandCardValue, ref int bestMaxCard, ref bool putCards)
        {
            //农民上家
            if (handCardData.gameRole == GameRole.Landlord)
            {
                //地主只剩一张牌，从大到小出
                if (handCardData.selfTurn && handCardData.GetEnemyCardsCount() < 2)
                {
                    bestHandCardValue.sumValue = int.MaxValue;
                    for (int i = GameSituationControl.I.newCardGroupData.maxCard + 1; i < 18; i++)
                    {
                        if (handCardData.handCardValueList[i] > 0)
                        {
                            //尝试打出一张牌，并估算剩余的手牌价值
                            handCardData.handCardValueList[i]--;
                            handCardData.handCardsCount--;
                            HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                            handCardData.handCardValueList[i]++;
                            handCardData.handCardsCount++;

                            //选取(总权值 - 轮次 * 7)最高的策略
                            if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) >=
                                (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                            {
                                bestHandCardValue = tmpHandCardValue;
                                bestMaxCard = i;
                                putCards = true;
                            }
                        }
                    }
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 主动出牌，地主只剩一张牌,最好不出单牌，否则从大到小出
        /// </summary>
        private static bool GetPutCardList_Active_Patch1(HandCardData handCardData, HandCardValue bestHandCardValue, int i, CardGroupData bestCardGroupData)
        {
            bool putCards = false;
            //农民上家
            if (handCardData.gameRole == GameRole.PeasantTop)
            {
                //地主只剩一张牌，从大到小出
                if (handCardData.selfTurn && handCardData.GetEnemyCardsCount() < 2)
                {
                    if (bestCardGroupData.cgType == CardGroupType.CT_SINGLE)
                        bestHandCardValue.sumValue += 30;

                    handCardData.handCardValueList[i]--;
                    handCardData.handCardsCount--;
                    HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                    handCardData.handCardValueList[i]++;
                    handCardData.handCardsCount++;

                    //选取(总权值 - 轮次 * 7)最高的策略
                    if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) >=
                        (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                    {
                        bestHandCardValue = tmpHandCardValue;
                        putCards = true;
                    }

                    if (putCards)
                    {
                        //能不出单牌就不出，将价值调小
                        bestHandCardValue.sumValue -= 30;
                    }

                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 主动出牌，农民只剩一张牌,最好不出单牌，否则从大到小出
        /// </summary>
        private static bool GetPutCardList_Active_Patch2(HandCardData handCardData, HandCardValue bestHandCardValue, int i, CardGroupData bestCardGroupData)
        {
            bool putCards = false;
            //地主
            if (handCardData.gameRole == GameRole.Landlord)
            {
                //农民只剩一张牌，从大到小出
                if (handCardData.selfTurn && handCardData.GetEnemyCardsCount() < 2)
                {
                    handCardData.handCardValueList[i]--;
                    handCardData.handCardsCount--;
                    HandCardValue tmpHandCardValue = CardAlgorithm.GetHandCardValue(handCardData);
                    handCardData.handCardValueList[i]++;
                    handCardData.handCardsCount++;

                    if (bestCardGroupData.cgType == CardGroupType.CT_SINGLE)
                        bestHandCardValue.sumValue += 30;

                    //选取(总权值 - 轮次 * 7)最高的策略
                    if ((bestHandCardValue.sumValue - (bestHandCardValue.needRound * 7)) >=
                        (tmpHandCardValue.sumValue - (tmpHandCardValue.needRound * 7)))
                    {
                        bestHandCardValue = tmpHandCardValue;
                        putCards = true;
                    }

                    if (putCards)
                    {
                        //能不出单牌就不出，将价值调小
                        bestHandCardValue.sumValue -= 30;
                    }

                    return true;
                }
            }
            return false;
        }
    }
}
