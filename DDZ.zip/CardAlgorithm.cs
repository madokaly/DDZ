using System;
using System.Collections.Generic;
using UnityEngine.Profiling;

namespace Proj_ddz_vr
{
    /// <summary>
    /// 卡牌算法类
    /// </summary>
    public static class CardAlgorithm
    {
        private static Dictionary<string, HandCardValue> value = new Dictionary<string, HandCardValue>();

        /// <summary>
        /// 洗牌算法
        /// </summary>
        /// <param name="handCardList"></param>
        public static void Reshuffle(List<int> handCardList)
        {
            Random random = new Random();
            int currentIndex;
            int tempValue;
            for (int i = 0; i < handCardList.Count; i++)
            {
                currentIndex = random.Next(0, handCardList.Count - 1);
                tempValue = handCardList[currentIndex];
                handCardList[currentIndex] = handCardList[handCardList.Count - 1 - i];
                handCardList[handCardList.Count - 1 - i] = tempValue;
            }

            /*for (int i = 0; i < 4; i++)
            {
                var split1 = random.Next(10, 34);
                var split2 = random.Next(split1 + 10, 44);
                var list1 = handCardList.GetRange(0, split1);
                var list2 = handCardList.GetRange(split1, split2 - split1);
                var list3 = handCardList.GetRange(split2 - split1, 54 - split2);
                handCardList.Clear();
                handCardList = handCardList.Union(list3).ToList<int>();
                handCardList = handCardList.Union(list1).ToList<int>();
                handCardList = handCardList.Union(list2).ToList<int>();
            }*/
        }

        /// <summary>
        /// 获得卡牌牌型价值
        /// </summary>
        /// <param name="cgType">牌型</param>
        /// <param name="maxCard"></param>
        /// <param name="count"></param>
        public static CardGroupData GetCardGroupDataValue(CardGroupType cgType, int maxCard, int count)
        {
            CardGroupData cardGroupData = new CardGroupData();
            cardGroupData.cgType = cgType;
            cardGroupData.maxCard = maxCard;
            cardGroupData.count = count;

            switch (cgType)
            {
                //不出牌型
                case CardGroupType.CT_ZERO:
                    cardGroupData.cardsValue = 0;
                    break;
                //单牌
                case CardGroupType.CT_SINGLE:
                    cardGroupData.cardsValue = maxCard - 10;
                    break;
                //对牌
                case CardGroupType.CT_DOUBLE:
                    cardGroupData.cardsValue = maxCard - 10;
                    break;
                //三条
                case CardGroupType.CT_THREE:
                    cardGroupData.cardsValue = maxCard - 10;
                    break;
                //单连
                case CardGroupType.CT_SINGLE_LINE:
                    cardGroupData.cardsValue = maxCard - 10 + 1;
                    break;
                //对连
                case CardGroupType.CT_DOUBLE_LINE:
                    cardGroupData.cardsValue = maxCard - 10 + 1;
                    break;
                //三连
                case CardGroupType.CT_THREE_LINE:
                    cardGroupData.cardsValue = (maxCard - 3 + 1) / 2;
                    break;
                //三带一单
                case CardGroupType.CT_THREE_TAKE_ONE:
                    cardGroupData.cardsValue = maxCard - 10;
                    break;
                //三带一对
                case CardGroupType.CT_THREE_TAKE_TWO:
                    cardGroupData.cardsValue = maxCard - 10;
                    break;
                //三带一单连
                case CardGroupType.CT_THREE_TAKE_ONE_LINE:
                    cardGroupData.cardsValue = (maxCard - 3 + 1) / 2;
                    break;
                //三带一对连
                case CardGroupType.CT_THREE_TAKE_TWO_LINE:
                    cardGroupData.cardsValue = (maxCard - 3 + 1) / 2;
                    break;
                //四带二单
                case CardGroupType.CT_FOUR_TAKE_ONE:
                    cardGroupData.cardsValue = (maxCard - 3) / 2;
                    break;
                //四带二对
                case CardGroupType.CT_FOUR_TAKE_TWO:
                    cardGroupData.cardsValue = (maxCard - 3) / 2;
                    break;
                //炸弹
                case CardGroupType.CT_BOMB_CARD:
                    cardGroupData.cardsValue = maxCard - 3 + 7;
                    break;
                //王炸
                case CardGroupType.CT_KING_CARD:
                    cardGroupData.cardsValue = 20;
                    break;
                //错误
                case CardGroupType.CT_ERROR:
                    cardGroupData.cardsValue = 0;
                    break;
            }
            return cardGroupData;
        }

        /// <summary>
        /// 获得手牌价值
        /// </summary>
        /// <param name="handCardData"></param>
        /// <returns></returns>
        public static HandCardValue GetHandCardValue(HandCardData handCardData)
        {
            Profiler.BeginSample("GetHandCardValue");
            //清空出牌
            handCardData.ClearPutCardList();

            HandCardValue handCardValue = new HandCardValue();
            //已经出完牌了
            if (handCardData.handCardsCount == 0)
            {
                handCardValue.sumValue = 0;
                handCardValue.needRound = 0;
                Profiler.EndSample();
                return handCardValue;
            }
            //剪枝：判断是否可以一手出完牌
            CardGroupData tempCardGroupData = JudgeIsOneRoundCardData(handCardData.handCardValueList);
            if (tempCardGroupData.cgType != CardGroupType.CT_ERROR)
            {
                handCardValue.sumValue = tempCardGroupData.cardsValue;
                handCardValue.needRound = 1;
                //XRLog.LogWarning($"一手牌：价值{handCardValue.sumValue}");
                Profiler.EndSample();
                return handCardValue;
            }

            //非一手能出完的牌
            //获取当先最佳出牌，即CardGroupData.putCardList和CardGroupData.newCardGroupData，不会调用出牌函数
            
            //缓存
            var key = UtilityHelper.GetHandCardString(handCardData.handCardValueList);
            if (value.ContainsKey(key)) 
            { 
                return value.GetValueOrDefault(key);
            }
            AiPlayAlgorithm.GetPutCardList_Active(handCardData);
            //保存当前的putCardList和NewCardGroupData用于回溯
            CardGroupData nowPutCardData = new CardGroupData
            {
                maxCard = handCardData.newCardGroupData.maxCard,
                cgType = handCardData.newCardGroupData.cgType,
                cardsValue = handCardData.newCardGroupData.cardsValue,
                count = handCardData.newCardGroupData.count
            };

            List<int> nowPutCardList = ListPool.Instance.GetPool();
            if (handCardData.putCardList.Count != 0)
            {
                foreach (var value in handCardData.putCardList)
                {
                    nowPutCardList.Add(value);
                }
            }

            //CardGroupData nowPutCardData = handCardData.newCardGroupData;
            //List<int> nowPutCardList = handCardData.putCardList;

            if (handCardData.newCardGroupData.cgType == CardGroupType.CT_ERROR)
            {
                //打印信息
            }

            //回溯开始--移除
            for (int i = 0; i < nowPutCardList.Count; i++)
            {
                handCardData.handCardValueList[nowPutCardList[i]]--;
            }
            handCardData.handCardsCount -= nowPutCardList.Count;
            //递归剩余手牌价值
            HandCardValue tempCardValue = GetHandCardValue(handCardData);
            //恢复
            for (int i = 0; i < nowPutCardList.Count; i++)
            {
                handCardData.handCardValueList[nowPutCardList[i]]++;
            }
            handCardData.handCardsCount += nowPutCardList.Count;
            //回溯结束

            handCardValue.sumValue = nowPutCardData.cardsValue + tempCardValue.sumValue;
            handCardValue.needRound = tempCardValue.needRound + 1;
            ListPool.Instance.RefreshList(nowPutCardList);
            if (!value.ContainsKey(key)) 
            { 
                value.Add(key, handCardValue);
            }
            
            Profiler.EndSample();
            return handCardValue;
        }

        /// <summary>
        /// 判断是否为一手牌
        /// </summary>
        /// <param name="handCardValueList"></param>
        /// <returns></returns>
        public static CardGroupData JudgeIsOneRoundCardData(int[] handCardValueList)
        {
            //手牌总数
            int cardCount = 0;
            for (int i = 3; i < 18; i++)
            {
                cardCount += handCardValueList[i];
            }
            CardGroupData retCardGroupData = new CardGroupData();
            retCardGroupData.count = cardCount;

            //单牌类型
            if (cardCount == 1)
            {
                //用于验证的变量
                int prov = 0;
                int sumValue = 0;
                for (int i = 3; i < 18; i++)
                {
                    if (handCardValueList[i] == 1)
                    {
                        sumValue = i - 10;
                        prov++;
                        retCardGroupData.maxCard = i;
                    }
                }

                if (prov == 1)
                {
                    retCardGroupData.cgType = CardGroupType.CT_SINGLE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //对牌类型
            if (cardCount == 2)
            {
                //用于验证的变量
                int prov = 0;
                int sumValue = 0;
                for (int i = 3; i < 16; i++)
                {
                    if (handCardValueList[i] == 2)
                    {
                        sumValue = i - 10;
                        prov++;
                        retCardGroupData.maxCard = i;
                    }
                }
                if (prov == 1)
                {
                    retCardGroupData.cgType = CardGroupType.CT_DOUBLE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //三条类型
            if (cardCount == 3)
            {
                //用于验证的变量
                int prov = 0;
                int sumValue = 0;
                for (int i = 3; i < 16; i++)
                {
                    if (handCardValueList[i] == 3)
                    {
                        sumValue = i - 10;
                        prov++;
                        retCardGroupData.maxCard = i;
                    }
                }
                if (prov == 1)
                {
                    retCardGroupData.cgType = CardGroupType.CT_THREE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //三带一单
            if (cardCount == 4)
            {
                //用于验证的变量
                int prov1 = 0;
                int prov2 = 0;
                int sumValue = 0;
                for (int i = 3; i < 18; i++)
                {
                    if (handCardValueList[i] == 3)
                    {
                        sumValue = i - 10;
                        prov1++;
                        retCardGroupData.maxCard = i;
                    }

                    if (handCardValueList[i] == 1)
                    {
                        prov2++;
                    }
                }
                if (prov1 == 1 && prov2 == 1)
                {
                    retCardGroupData.cgType = CardGroupType.CT_THREE_TAKE_ONE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //三带一对
            if (cardCount == 5)
            {
                //用于验证的变量
                int prov1 = 0;
                int prov2 = 0;
                int sumValue = 0;
                for (int i = 3; i < 16; i++)
                {
                    if (handCardValueList[i] == 3)
                    {
                        sumValue = i - 10;
                        prov1++;
                        retCardGroupData.maxCard = i;
                    }

                    if (handCardValueList[i] == 2)
                    {
                        prov2++;
                    }
                }
                if (prov1 == 1 && prov2 == 1)
                {
                    retCardGroupData.cgType = CardGroupType.CT_THREE_TAKE_TWO;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //四带二单
            if (cardCount == 6)
            {
                //用于验证的变量
                int prov1 = 0;
                int prov2 = 0;
                int sumValue = 0;
                for (int i = 3; i < 18; i++)
                {
                    if (handCardValueList[i] == 4)
                    {
                        sumValue = (i - 3) / 2;
                        prov1++;
                        retCardGroupData.maxCard = i;
                    }

                    if (handCardValueList[i] == 1 || handCardValueList[i] == 2)
                    {
                        prov2 += handCardValueList[i];
                    }
                }
                if (prov1 == 1 && prov2 == 2)
                {
                    retCardGroupData.cgType = CardGroupType.CT_FOUR_TAKE_ONE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //四带二对
            if (cardCount == 8)
            {
                //用于验证的变量
                int prov1 = 0;
                int prov2 = 0;
                int sumValue = 0;
                for (int i = 3; i < 16; i++)
                {
                    if (handCardValueList[i] == 4)
                    {
                        sumValue = (i - 3) / 2;
                        prov1++;
                        retCardGroupData.maxCard = i;
                    }

                    if (handCardValueList[i] == 2 || handCardValueList[i] == 4)
                    {
                        prov2 += handCardValueList[i] / 2;
                    }
                }
                if (prov1 == 1 && prov2 == 4)
                {
                    retCardGroupData.cgType = CardGroupType.CT_FOUR_TAKE_TWO;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //炸弹
            if (cardCount == 4)
            {
                //用于验证的变量
                int prov = 0;
                int sumValue = 0;
                for (int i = 3; i < 16; i++)
                {
                    if (handCardValueList[i] == 4)
                    {
                        sumValue = i - 3 + 7;
                        prov++;
                        retCardGroupData.maxCard = i;
                    }
                }
                if (prov == 1)
                {
                    retCardGroupData.cgType = CardGroupType.CT_BOMB_CARD;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //王炸
            if (cardCount == 2)
            {
                if (handCardValueList[17] > 0 && handCardValueList[16] > 0)
                {
                    int sumValue = 20;
                    retCardGroupData.maxCard = 17;
                    retCardGroupData.cgType = CardGroupType.CT_KING_CARD;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //单连类型
            if (cardCount >= 5)
            {
                //用于验证的变量
                int prov = 0;
                int sumValue = 0;
                int i;
                for (i = 3; i < 15; i++)
                {
                    if (handCardValueList[i] == 1)
                    {
                        prov++;
                    }
                    else
                    {
                        if (prov != 0) break;
                    }
                }

                sumValue = i - 10;
                if (prov == cardCount)
                {
                    retCardGroupData.maxCard = i - 1;
                    retCardGroupData.cgType = CardGroupType.CT_SINGLE_LINE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //对连类型
            if (cardCount >= 6)
            {
                //用于验证的变量
                int prov = 0;
                int sumValue = 0;
                int i;
                for (i = 3; i < 15; i++)
                {
                    if (handCardValueList[i] == 2)
                    {
                        prov++;
                    }
                    else
                    {
                        if (prov != 0) break;
                    }
                }

                sumValue = i - 10;
                if (prov * 2 == cardCount)
                {
                    retCardGroupData.maxCard = i - 1;
                    retCardGroupData.cgType = CardGroupType.CT_DOUBLE_LINE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //三连类型
            if (cardCount >= 6)
            {
                //用于验证的变量
                int prov = 0;
                int sumValue = 0;
                int i;
                for (i = 3; i < 15; i++)
                {
                    if (handCardValueList[i] == 3)
                    {
                        prov++;
                    }
                    else
                    {
                        if (prov != 0) break;
                    }
                }

                sumValue = (i - 3) / 2;
                if (prov * 3 == cardCount)
                {
                    retCardGroupData.maxCard = i - 1;
                    retCardGroupData.cgType = CardGroupType.CT_THREE_LINE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //三带一连类型
            if (cardCount >= 8)
            {
                //用于验证的变量
                int prov = 0;
                int sumValue = 0;
                int i;
                for (i = 3; i < 15; i++)
                {
                    if (handCardValueList[i] >= 3)
                    {
                        prov++;
                    }
                    else
                    {
                        if (prov != 0) break;
                    }
                }

                sumValue = (i - 3) / 2;
                if (prov * 4 == cardCount)
                {
                    retCardGroupData.maxCard = i - 1;
                    retCardGroupData.cgType = CardGroupType.CT_THREE_TAKE_ONE_LINE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            //三带二连类型
            if (cardCount >= 10)
            {
                //用于验证的变量
                int prov1 = 0;
                int prov2 = 0;
                int sumValue = 0;
                int i, j;
                for (i = 3; i < 15; i++)
                {
                    if (handCardValueList[i] == 3)
                    {
                        prov1++;
                    }
                    else
                    {
                        if (prov1 != 0) break;
                    }
                }

                for (j = 3; j < 16; j++)
                {
                    if (handCardValueList[j] == 2 || handCardValueList[j] == 4)
                    {
                        prov2 += handCardValueList[j] / 2;
                    }
                }

                sumValue = (i - 3) / 2;
                if (prov1 * 5 == cardCount && prov1 == prov2)
                {
                    retCardGroupData.maxCard = i - 1;
                    retCardGroupData.cgType = CardGroupType.CT_THREE_TAKE_TWO_LINE;
                    retCardGroupData.cardsValue = sumValue;
                    return retCardGroupData;
                }
            }

            retCardGroupData.cgType = CardGroupType.CT_ERROR;
            return retCardGroupData;
        }

        public static int JudgeDiPaiScore(int[] diPai)
        {
            //排序
            List<int> cards = new List<int>();
            foreach (var value in diPai)
            {
                cards.Add(value);
            }
            cards.Sort();

            //顺子
            if (cards[0] + 1 == cards[1] && cards[0] + 2 == cards[2]) return 3;
            //三张相同
            if (cards[0] == cards[1] && cards[0] == cards[1]) return 3;
            //大王小王
            if (cards.Contains(52) && cards.Contains(56)) return 4;
            //大王或小王
            if (cards.Contains(52) || cards.Contains(56)) return 2;
            //对子
            if ((cards[0] == cards[1] && cards[0] != cards[2]) ||
                (cards[1] == cards[2] && cards[0] != cards[1])) return 2;
            return 1;
        }
    }
}
