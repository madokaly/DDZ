namespace Proj_ddz_vr
{
    /// <summary>
    /// 卡牌牌型类
    /// </summary>
    public struct CardGroupData
    {
        /// <summary>
        /// 牌型
        /// </summary>
 //       public CardGroupType cgType = CardGroupType.CT_ERROR;
        public CardGroupType cgType;

        /// <summary>
        /// 该牌价值
        /// </summary>
        public int cardsValue;

        /// <summary>
        /// 含牌数量
        /// </summary>
        public int count;

        /// <summary>
        /// 最大牌值-用于对比牌大小
        /// </summary>
        public int maxCard;
    }
}
